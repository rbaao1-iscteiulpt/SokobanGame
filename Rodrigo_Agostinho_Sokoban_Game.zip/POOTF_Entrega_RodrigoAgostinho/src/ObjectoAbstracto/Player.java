
package ObjectoAbstracto;

import java.util.Random;
import javax.swing.JOptionPane;
import MotorDeJogo.SokobanGame;
import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 */
public class Player extends ObjectoAbstracto implements ObjectoActivo{

	public SokobanGame sokoban;
	private String imageName;
	private int energia;
	private int numeroMovimentos;

	/**
	 * E criado um objeto Player que tem uma imagem, energia e numeroDeMovimentos
	 * @param position
	 * @param sokobanGame
	 */
	public Player(Position position, SokobanGame sokobanGame){
		super(position, false, false, false);
		this.imageName = "Empilhadora_U";
		this.sokoban = sokobanGame;
		this.energia = 100;
		this.numeroMovimentos = 0;
		ImageMatrixGUI.getInstance().setStatusMessage("Nivel:"+ sokoban.getNivel() +"  Numero de movimentos:" + numeroMovimentos + "  Energia:" + energia);
	}

	@Override
	public String getName() {
		return imageName;
	}

	@Override
	public int getLevel() {
		return 1;
	}

	public int getEnergia() {
		return energia;
	}

	public void setEnergia(int energia) {
		if (energia < 0) {
			throw new IllegalArgumentException();
		} else {	 
			this.energia = energia;
		}	
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public int getNumeroMovimentos() {
		return numeroMovimentos;
	}

	public void setNumeroMovimentos(int numeroMovimentos) {
		this.numeroMovimentos = numeroMovimentos;
	}

	@Override
	public boolean isActivable(Position p){
		return sokoban.verifyIfItCanActivate(p);
	}

	@Override
	public boolean isPassable(Position p) {
		return sokoban.verifyIfItCanPass(p);
	}

	/**
	 * Verifica se a posicao para a qual nos queremos movimentar contem um objecto a empurrar
	 * @param position
	 * @return boolean
	 */
	private boolean isPushable(Position position){
		return sokoban.verifyIfItCanPush(position);
	}

	public void move() {
		// Generate a random vector for movement
		Direction[] possibleDirections = Direction.values();

		Random randomizer = new Random();
		int randomNumber = randomizer.nextInt(possibleDirections.length);

		Direction randomDirection = possibleDirections[randomNumber];

		Position newPosition = position.plus(randomDirection.asVector());
		if (newPosition.getX()>=0 && newPosition.getX()<10 && newPosition.getY()>=0 && newPosition.getY()<10 && isPassable(newPosition)){
			if(isPassable(newPosition)){
				this.position = newPosition;
			} 
			if(isActivable(newPosition)){
				sokoban.chooseActivable(newPosition).activate();
			}
		updateAll();
		}
	}

		@Override
		public void moveWithDirection(int lastKeyPressed) {
			Position newPosition = position.plus(Direction.directionFor(lastKeyPressed).asVector());
			if( newPosition.getX()>=0 && newPosition.getX()<10 && newPosition.getY()>=0 && newPosition.getY()<10 ){
				if(isPassable(newPosition)){
					this.position = newPosition;
				} else if(isPushable(newPosition) && isPassable(newPosition.plus(Direction.directionFor(lastKeyPressed).asVector()))){
					sokoban.chooseActive(newPosition).moveWithDirection(lastKeyPressed);
					this.position = newPosition;
				}
				if(isActivable(newPosition)){
					sokoban.chooseActivable(newPosition).activate();
				}
				updateAll();
			}
		}
	
	/**
	 * Verifica se a bateria j� esgotou
	 */
	private void checkBattery(){
		if(energia <= 0){
			ImageMatrixGUI.getInstance().dispose();
			JOptionPane.showMessageDialog(null, "GameOver: Esgotou bateria!");
		}
	}

	/**
	 * Incrementa o numero de movimentos e decrementa a energia
	 */
	private void increaseMovementsAndDecreaseBattery(){
		numeroMovimentos++;
		energia = energia-1;
	}

	private void updateStatusBox(){
		ImageMatrixGUI.getInstance().setStatusMessage("Nivel:"+ sokoban.getNivel() +"  N�mero de movimentos:" + numeroMovimentos + "  Energia:" + energia);
	}

	private void updateAll(){
		increaseMovementsAndDecreaseBattery();
		checkBattery();
		updateStatusBox();		
		sokoban.nextLevel();
		ImageMatrixGUI.getInstance().update();
	}

}