package ObjectoAbstracto;

import MotorDeJogo.SokobanGame;
import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Position;

/**
 * 
 * @author Rodrigo
 *
 */

public class BigStone extends ObjectoAbstracto implements ObjectoActivo {
	
	private SokobanGame sokoban;
	
	/**
	 * Cria um objecto do tipo BigStone, sendo este um objecto activo
	 * @param position
	 * @param sokobanGame
	 */
	
	public BigStone(Position position, SokobanGame sokobanGame){
		super(position, false, true, false);
		this.sokoban = sokobanGame;
	}

	@Override
	public String getName() {
		return "BigStone";
	}

	@Override
	public int getLevel() {
		return 1;
	}

	@Override
	public boolean isPassable(Position p) {
		return sokoban.verifyIfItCanPass(p);
	}
	
	@Override
	public boolean isActivable(Position p){
		return sokoban.verifyIfItCanActivate(p);
	}
	
	@Override
	public void moveWithDirection(int lastKeyPressed){
		Position newPosition = position.plus(Direction.directionFor(lastKeyPressed).asVector());
		if (newPosition.getX()>=0 && newPosition.getX()<10 && newPosition.getY()>=0 && newPosition.getY()<10 && isPassable(newPosition)){
			this.position = newPosition;
			if(isActivable(newPosition)){
				sokoban.chooseActivable(this.position).activate();
			}
		}
		ImageMatrixGUI.getInstance().update();
	}

}