package ObjectoAbstracto;

import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 */
public class Parede extends ObjectoAbstracto{

	/**
	 * Cria um objecto parede
	 * @param position
	 */
	public Parede(Position position){
		super(position, false, false, false);
	}

	@Override
	public String getName() {
		return "Parede";
	}

	@Override
	public int getLevel() {
		return 0;
	}

}
