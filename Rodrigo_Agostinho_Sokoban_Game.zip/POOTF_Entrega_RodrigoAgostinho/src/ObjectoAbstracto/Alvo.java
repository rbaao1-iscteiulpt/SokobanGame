package ObjectoAbstracto;

import pt.iul.ista.poo.utils.Position;

/**
 * 
 * @author Rodrigo
 *
 */

public class Alvo extends ObjectoAbstracto {
	
	/**
	 * Cria um objecto alvo, sendo estes os objectos a ser usados para colocar os caixotes de modo a passar de nivel
	 * @param position
	 */
	
	public Alvo(Position position){
		super(position, true, false, false);
	}

	@Override
	public String getName() {
		return "Alvo";
	}

	@Override
	public int getLevel() {
		return 0;
	}

}
