package ObjectoAbstracto;

import MotorDeJogo.SokobanGame;
import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 */

public class Bateria extends ObjectoAbstracto implements ObjectoActivavel{

	private SokobanGame sokoban;

	/**
	 * Cria um objecto do tipo bateria, sendo este um objecto activavel
	 * @param position
	 * @param sokobanGame
	 */
	
	public Bateria(Position position, SokobanGame sokobanGame){
		super(position, true, false, true);
		this.sokoban = sokobanGame;
	}

	@Override
	public String getName() {
		return "Bateria";
	}

	@Override
	public int getLevel() {
		return 0;
	}

	@Override
	public void activate() {
		ObjectoAbstracto objecto = (ObjectoAbstracto) sokoban.chooseActive(this.position);
		if(objecto instanceof Player){
			sokoban.deleteObject(this);
			sokoban.addObject(new Chao(this.position));
			sokoban.addEnergy();
		}
	}

}
