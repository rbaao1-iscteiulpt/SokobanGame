package ObjectoAbstracto;

import pt.iul.ista.poo.utils.Position;

public class Chao extends ObjectoAbstracto{

	/**
	 * Cria um objecto chao
	 * @param position
	 */
	public Chao(Position position){
		super(position,true, false, false);
	}

	@Override
	public String getName() {
		return "Chao";
	}

	@Override
	public int getLevel() {
		return 0;
	}

}
