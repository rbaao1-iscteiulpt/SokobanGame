package ObjectoAbstracto;

import pt.iul.ista.poo.utils.Position;

/**
 * 
 * @author Rodrigo
 *
 */

public interface ObjectoActivo {

	/**
	 * Verifica se a posicao para a qual se quer movimentar e passavel
	 * @param position
	 * @return boolean
	 */
	boolean isPassable(Position position);
	
	/**
	 * Verifica se o objecto na posi��o para a qual se quer movimentar � activavel
	 * @param position
	 * @return boolean
	 */
	boolean isActivable(Position position);


	/**
	 * Permite efectuar um movimento dada uma tecla pressionada
	 * @param lastKeyPressed
	 */
	void moveWithDirection(int lastKeyPressed);
	
}

/* isPushable() n�o foi implementado como m�todo da interface uma vez que apenas o player � que empurra objectos. */
