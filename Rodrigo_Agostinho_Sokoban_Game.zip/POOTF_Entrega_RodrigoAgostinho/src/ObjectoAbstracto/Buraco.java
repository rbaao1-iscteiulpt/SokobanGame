package ObjectoAbstracto;

import javax.swing.JOptionPane;

import MotorDeJogo.SokobanGame;
import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 */

public class Buraco extends ObjectoAbstracto implements ObjectoActivavel {

	private SokobanGame sokoban;
	
	/**
	 *  Cria um objecto do tipo buraco, sendo este um objecto activavel
	 * @param position
	 * @param sokobanGame
	 */
	public Buraco(Position position, SokobanGame sokobanGame){
		super(position, true, false, true);
		this.sokoban = sokobanGame;
	}

	@Override
	public String getName() {
		return "Buraco";
	}

	@Override
	public int getLevel() {
		return 0;
	}

	@Override
	public void activate() {
		ObjectoAbstracto objecto = (ObjectoAbstracto) sokoban.chooseActive(this.position);
		if(objecto instanceof Player){
			ImageMatrixGUI.getInstance().dispose();
			JOptionPane.showMessageDialog(null, "GameOver: Lamentamos informar que caiu na escuridao! :(");
		} else if(objecto instanceof Caixote){
			sokoban.deleteObject(objecto);
			System.out.println("Caixote caiu no buraco");
		} else if(objecto instanceof SmallStone){
			sokoban.deleteObject(objecto);
			System.out.println("Pedra pequena caiu no buraco");
		} else if(objecto instanceof BigStone){
			objecto.setPassable(false);
			objecto.setPushable(false);
			System.out.println("Pedra grande caiu no buraco");
		}
	}

}
