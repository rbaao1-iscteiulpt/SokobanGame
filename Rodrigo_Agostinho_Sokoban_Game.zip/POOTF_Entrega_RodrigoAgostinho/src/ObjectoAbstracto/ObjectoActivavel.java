package ObjectoAbstracto;

/**
 * @author Rodrigo
 *
 */

public interface ObjectoActivavel {

	/**
	 * Se o objecto for encontrado, e activado executando um determinado metodo, definido na classe dos objectos que implementam 
	 * esta interface
	 */
	void activate();
	
}
