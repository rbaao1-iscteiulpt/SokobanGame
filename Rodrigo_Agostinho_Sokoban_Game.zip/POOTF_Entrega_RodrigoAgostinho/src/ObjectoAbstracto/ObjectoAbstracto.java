package ObjectoAbstracto;

import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 * Objecto abstracto � um classe abstracta que vai ser extendida por todos os objectos. Posteriormente � usado o super para criar 
 * os objectos mais especificos
 */

public abstract class ObjectoAbstracto implements ImageTile{

	public Position position;
	private Boolean passable;
	private Boolean pushable;
	private Boolean isActivable;
	private int teste;

	/**
	 * Constroi um objecto abstracto 
	 * @param position
	 * @param passable
	 * @param pushable
	 * @param activable
	 */
	public ObjectoAbstracto(Position position, Boolean passable, Boolean pushable, Boolean activable){
		this.position = position;
		this.passable = passable;
		this.pushable = pushable;
		this.isActivable = activable;
		this.teste = 0;
	}

	@Override
	public Position getPosition() {
		return position;
	}
	
	public void setPosition(Position position) {
		this.position = position;
	}
	
	public Boolean getPassable() {
		return passable;
	}
	
	public void setPassable(Boolean passable) {
		this.passable = passable;
	}
	
	public boolean getPushable(){
		return pushable;
	}

	public void setPushable(Boolean pushable){
		this.pushable = pushable;
	}

	public Boolean getIsActivable() {
		return isActivable;
	}

	public void setIsActivable(Boolean isActivable) {
		this.isActivable = isActivable;
	}
	
	public int getTeste(){
		return teste;
	}
	
	
}
