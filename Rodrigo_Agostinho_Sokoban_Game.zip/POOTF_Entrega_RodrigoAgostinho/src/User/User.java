package User;

/**
 * @author Rodrigo
 *
 */
public class User {

	private String username;

	/**
	 * Cria um user dado um nome(string)
	 * @param string
	 */
	public User(String string){
		if(!string.trim().isEmpty()){ //para n�o aceitar um nome sem nada porque isso ia dar problemas na leitura do ficheiro
			this.username = string;
		} else {
			this.username = "Anonimo";
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


}
