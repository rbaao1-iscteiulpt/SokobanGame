package MotorDeJogo;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

import javax.swing.JOptionPane;

import ObjectoAbstracto.Alvo;
import ObjectoAbstracto.Bateria;
import ObjectoAbstracto.BigStone;
import ObjectoAbstracto.Buraco;
import ObjectoAbstracto.Caixote;
import ObjectoAbstracto.Chao;
import ObjectoAbstracto.ObjectoAbstracto;
import ObjectoAbstracto.ObjectoActivavel;
import ObjectoAbstracto.ObjectoActivo;
import ObjectoAbstracto.Parede;
import ObjectoAbstracto.Player;
import ObjectoAbstracto.SmallStone;
import User.User;
import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Position;

/**
 * @author Rodrigo
 *
 */
public class SokobanGame implements Observer {

	private ArrayList<ImageTile> tiles;
	private List<ObjectoAbstracto> listaDeObjectos;
	private Player player;
	private User user;
	private int numeroAlvos;
	private int nivel;	

	/**
	 * Cria o jogo, dado um utilizador, e constroi o nivel 
	 * @param user
	 */
	public SokobanGame(User user) {
		this.nivel = 0;
		buildLevel("levels/level"+nivel+".txt");
		System.out.println("Numero de alvos a destruir neste nivel: " + numeroAlvos);
		this.user = user;
	}

	/**
	 * Cria o mapa do nivel lendo um ficheiro e lança a interface, guardando os objectos lidos numa lista de objectos abstractos
	 * @param fileName
	 */
	private void buildLevel(String fileName)  {

		listaDeObjectos = new ArrayList<ObjectoAbstracto>();
		tiles = new ArrayList<ImageTile>();
		numeroAlvos=0;
		int j; 

		try {
			Scanner scanner = new Scanner(new File(fileName));
			j = 0;
			while(scanner.hasNext()){

				String line = scanner.nextLine();
				System.out.println(line);
				char c[] = line.toCharArray();
				for(int i = 0; i < c.length; i++){
					if(c[i]=='#') {
						tiles.add(new Parede(new Position(i,j)));
						listaDeObjectos.add(new Parede(new Position(i,j)));
					}
					if(c[i]=='C') {
						Caixote caixote = new Caixote(new Position(i,j), this);
						addObject(new Chao(new Position(i,j)));
						tiles.add(caixote);
						listaDeObjectos.add(caixote);
					}
					if(c[i]=='E') {
						player = new Player(new Position(i,j),this);
						addObject(new Chao(new Position(i,j)));
						tiles.add(player);
						listaDeObjectos.add(player);
					}
					if(c[i]=='b') {
						tiles.add(new Bateria(new Position(i,j),this));
						listaDeObjectos.add(new Bateria(new Position(i,j),this));
					} 
					if(c[i]=='O') {
						tiles.add(new Buraco(new Position(i,j), this));
						listaDeObjectos.add(new Buraco(new Position(i,j), this));
					}
					if(c[i]=='Z'){
						SmallStone small = new SmallStone(new Position(i,j), this);
						addObject(new Chao(new Position(i,j)));
						tiles.add(small);
						listaDeObjectos.add(small);
					}
					if(c[i]=='L'){
						BigStone big = new BigStone(new Position(i,j), this);
						addObject(new Chao(new Position(i,j)));
						tiles.add(big);
						listaDeObjectos.add(big);
					}
					if(c[i]=='X'){
						tiles.add(new Alvo(new Position(i, j)));
						listaDeObjectos.add(new Alvo(new Position(i,j)));
						numeroAlvos++;
					}
					if(c[i]==' ') {
						tiles.add(new Chao(new Position(i,j)));
						listaDeObjectos.add(new Chao(new Position(i,j)));
					}
				}
				j++;
			}
			scanner.close();

		} catch (final FileNotFoundException e) {
			System.out.println("Nao foi possível encontrar ficheiro de nivel!");
			ImageMatrixGUI.getInstance().dispose();
			JOptionPane.showMessageDialog(null, "Nao foi possível encontrar nivel!");
			System.exit(1);
		}
		ImageMatrixGUI.getInstance().addImages(tiles);
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		int lastKeyPressed = (Integer) arg1;
		System.out.println("Key pressed " + lastKeyPressed);
		if (lastKeyPressed == KeyEvent.VK_RIGHT) {
			if (player != null){
				player.setImageName("Empilhadora_R");
				player.moveWithDirection(lastKeyPressed);
			}
		}
		if (lastKeyPressed == KeyEvent.VK_LEFT ) {
			if (player != null ){
				player.setImageName("Empilhadora_L");
				player.moveWithDirection(lastKeyPressed);
			}
		}
		if (lastKeyPressed == KeyEvent.VK_UP) {
			if (player != null){ 
				player.setImageName("Empilhadora_U");
				player.moveWithDirection(lastKeyPressed);
			}
		}
		if (lastKeyPressed == KeyEvent.VK_DOWN) {
			if (player != null){
				player.setImageName("Empilhadora_D");
				player.moveWithDirection(lastKeyPressed);
			}
		}
		if (lastKeyPressed == KeyEvent.VK_ENTER) { //movimento aleatório
			if (player != null){
				player.move();
			}
		}
	}

	/**
	 * Valida a existencia de um objecto numa dada posicao atraves do nome do objecto(string)
	 * @param position
	 * @param objectName
	 * @return boolean
	 */

	public boolean validateExistence(Position position, String objectName){
		for( ObjectoAbstracto objecto : listaDeObjectos){
			if(objecto.getPosition().equals(position) && objecto.getName().equals(objectName)){
				return true;
			}
		}
		return false;
	}

	public int getNivel(){
		return nivel;
	}

	/**
	 *Por vezes temos 2 objectos na mesma posição, logo é necessário devolver uma lista de todos os objectos
	 * que se encontram numa dada posição de modo a poder fazer verificacoes
	 * @param position
	 * @return List<ObjectoAbstracto>
	 */
	private List<ObjectoAbstracto> chooseObjectsInxPosition(Position position){
		List<ObjectoAbstracto> objectosNaPosicao = new ArrayList<ObjectoAbstracto>();
		for(ObjectoAbstracto objecto : listaDeObjectos){
			if(objecto.getPosition().equals(position)){
				objectosNaPosicao.add(objecto);
			}
		}
		return objectosNaPosicao;
	}	

	/**
	 * Dada uma posicão devolve o objecto activo nessa posição fazendo a verificacao da existencia do mesmo através da iteração
	 * de uma lista de objectos. Um objecto é activo se for empurrável ou se o objecto for um player
	 * @param position
	 * @return ObjectoActivo
	 */
	public ObjectoActivo chooseActive(Position position){ 
		List<ObjectoAbstracto> lista = chooseObjectsInxPosition(position);
		for(ObjectoAbstracto objecto : lista){
			if(objecto.getPosition().equals(position) && (objecto.getPushable()==true || objecto instanceof Player )){
				return (ObjectoActivo) objecto;
			}
		}
		return null;
	}

	/**
	 *  Dada uma posicão devolve o objecto activavel nessa posição fazendo a verificacao da existencia do mesmo através da iteracao
	 * de uma lista de objectos. Um objecto é activavel se tiver um atributo, isActivable com valor booleano true
	 * @param position
	 * @return ObjectoActivavel
	 */
	public ObjectoActivavel chooseActivable(Position position){ 
		List<ObjectoAbstracto> lista = chooseObjectsInxPosition(position);
		for(ObjectoAbstracto objecto : lista){
			if(objecto.getPosition().equals(position) && objecto instanceof ObjectoActivavel){
				return (ObjectoActivavel) objecto;
			}
		}
		return null;
	}

	/**
	 * Verifica se os objectos de uma lista de objectos numa dada posicao sao passaveis,
	 * se algum deles não for passavel nao e possivel efectuar o movimento
	 * @param position
	 * @return boolean
	 */
	public boolean verifyIfItCanPass(Position position){
		List<ObjectoAbstracto> lista = chooseObjectsInxPosition(position);
		for(ObjectoAbstracto objecto: lista){
			if(objecto.getPassable()==false){
				return false;
			}
		}
		return true;
	}

	/**
	 * Verifica se os objectos da lista de uma dada posicao são empurraveis, se algum for, quer dizer que e possivel empurrar
	 * @param position
	 * @return boolean
	 */
	public boolean verifyIfItCanPush(Position position){
		List<ObjectoAbstracto> lista = chooseObjectsInxPosition(position);
		for(ObjectoAbstracto objecto: lista){
			if(objecto.getPassable()==false && objecto.getPushable()==true){
				return true;
			}
		}
		return false;
	}

	/**
	 * Verifica se os objectos da lista de uma dada posicao são activaveis, se algum for, quer dizer que e possivel activar
	 * @param position
	 * @return boolean
	 */
	public boolean verifyIfItCanActivate(Position position){
		List<ObjectoAbstracto> lista = chooseObjectsInxPosition(position);
		for(ObjectoAbstracto objecto: lista){
			if(objecto.getIsActivable()==true){
				return true;
			}
		}
		return false;
	}

	/**
	 * Adiciona energia ao player 
	 */
	public void addEnergy(){
		player.setEnergia(100);
		System.out.println("Apanhou bateria");
	}

	/**
	 * Verifica os objectos que estao na posicao dos alvos, usando para tal uma lista de alvos,
	 * verificando se cada um deles tem um caixote, se todos tiverem , devolve verdadeiro. 
	 * Esta verificacao e feita a cada movimento do player, para garantir que se o player voltar a empurrar o caixote, o valor nao incrementa
	 * ou que se passarmos varias vezes o mesmo caixote num alvo nao e sempre incrementado e passamos de nivel quando na verdade
	 * os caixotes nao estavam todos nos alvos
	 * @return boolean
	 */
	private boolean verifyAllTargets(){
		List<ObjectoAbstracto> listaDeAlvos = new ArrayList<>();
		for(ObjectoAbstracto objecto0 : listaDeObjectos){
			if(objecto0 instanceof Alvo){
				listaDeAlvos.add(objecto0);
			}
		}
		int boxesOnTargets=0;
		for(ObjectoAbstracto alvo : listaDeAlvos){
			List<ObjectoAbstracto> listaDeObjectosNaPosicaoDoAlvo = chooseObjectsInxPosition(alvo.getPosition());
			for(ObjectoAbstracto objecto : listaDeObjectosNaPosicaoDoAlvo){
				if(objecto instanceof Caixote){
					boxesOnTargets++;
					if(boxesOnTargets == numeroAlvos){
						return true;
					}
				} 
			}
		}
		return false;
	}

	/**
	 * Apaga objecto da interface e da lista de objectos
	 * @param objecto
	 */
	public void deleteObject(ObjectoAbstracto objecto){
		listaDeObjectos.remove(objecto);
		tiles.remove(objecto);
		ImageMatrixGUI.getInstance().removeImage(objecto);
	}

	/**
	 * Adiciona um objecto a interface e a lista de objectos
	 * @param objecto
	 */
	public void addObject(ObjectoAbstracto objecto){
		listaDeObjectos.add(objecto);
		tiles.add(objecto);
		ImageMatrixGUI.getInstance().addImage(objecto);
	}

	private void removeItemsFromList(){
		listaDeObjectos.removeAll(listaDeObjectos);
	}

	/**
	 * Para guardar as 5 melhores pontuacoes de cada nivel num ficheiro. Sao lidos os ficheiros e guardados numa lista e organizados utilizando o sort
	 * para guardar apenas os 5 melhores, posteriormente sao escritos no ficheiro. 
	 * Se ao ler o ficheiro este nao existir, e criado
	 * @param numeroMovimentos
	 */
	private void scoreLog(int numeroMovimentos){
		try{
			Scanner highscore_tmp = new Scanner( new File("./Scores/pontuacoes"+nivel+".txt") );

			List<PlayerScore> highscore_Players = new ArrayList<>();

			while(highscore_tmp.hasNextLine()){
				String line = highscore_tmp.nextLine();
				if(line.equalsIgnoreCase("#5MelhoresPontuacoes")){

				} else {
					String[] playersinfile = line.split(" ");
					String posicaonoficheiro = playersinfile[0];
					String[] posicaonoficheirofinal = posicaonoficheiro.split("#");
					String[] level = playersinfile[2].split(":");
					String[] name = playersinfile[4].split(":");				
					String[] score = playersinfile[6].split(":");
					String[] scorefinal = score[1].split("]");
					highscore_Players.add(new PlayerScore(Integer.parseInt(posicaonoficheirofinal[1]), Integer.parseInt(level[1]), name[1], Integer.parseInt(scorefinal[0])));
				}
			}

			try {
				highscore_Players.add(new PlayerScore(0, nivel, user.getUsername(), numeroMovimentos));

				Collections.sort(highscore_Players);

				FileWriter file = new FileWriter( new File("./Scores/pontuacoes"+nivel+".txt"),false); //faz replace do que ja existe
				PrintWriter fileWriter  = new PrintWriter(file);
				fileWriter.println("#5MelhoresPontuacoes");

				int bestplayers = 1;
				for(PlayerScore player: highscore_Players){
					if(bestplayers<6){
						player.setPosicao(bestplayers);
						fileWriter.println(player);
						bestplayers++;
					} else {
						break;
					}
				}

				System.out.println("Gravado no ficheiro!");
				fileWriter.close();

			} catch (FileNotFoundException e){
				System.out.println("*[ERRO ESCRITA FICHEIRO]* Ficheiro nao encontrado!");	

			} catch (IOException e) {
				e.printStackTrace();
			}

			highscore_tmp.close();


		} catch (FileNotFoundException e){
			System.out.println("*[ERRO LEITURA FICHEIRO]* Ficheiro nao encontrado!");	

			try {
				/* se o ficheiro não existir, cria-o e adiciona a pontuação do player */

				PrintWriter fileWriter  = new PrintWriter( new File("./Scores/pontuacoes"+nivel+".txt"));

				fileWriter.println("#5MelhoresPontuacoes");
				fileWriter.println(new PlayerScore(1, nivel, user.getUsername(), numeroMovimentos));

				fileWriter.close();
				System.out.println("Ficheiro criado e adicionada pontuação");

			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * Funcao que permite passar de nivel, invocando a funcao buildlevel e guardando a pontuacao num ficheiro invocando a funcao
	 * ScoreLog
	 */
	public void nextLevel(){ 
		if(verifyAllTargets() == true){ 
			scoreLog(player.getNumeroMovimentos()); //se passar para o nivel seguinte guarda a pontuação do jogador
			nivel += 1;
			ImageMatrixGUI.getInstance().removeImages(tiles);
			removeItemsFromList();
			buildLevel("levels/level"+(nivel)+".txt");
			ImageMatrixGUI.getInstance().addImages(tiles);
			ImageMatrixGUI.getInstance().go();
		}
	}
	
}
