package MotorDeJogo;

/**
 * @author Rodrigo
 *
 */
public class PlayerScore  implements Comparable<PlayerScore> {
	
	private int posicao;
	private int nivel;
	private String userName;
	private int pontuacao;
	
	/**
	 * Cria um PlayerScore, a ser guardado posteriormente num ficheiro de pontuacoes
	 * @param posicao
	 * @param nivel
	 * @param userName
	 * @param pontuacao
	 */
	public PlayerScore(int posicao, int nivel, String userName, int pontuacao){
		this.posicao = posicao;
		this.nivel = nivel;
		this.userName = userName;
		this.pontuacao = pontuacao;
	}
	
	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPontuacao() {
		return pontuacao;
	}

	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}
	
	public int getPosicao() {
		return posicao;
	}

	public void setPosicao(int posicao) {
		this.posicao = posicao;
	}

	@Override
	public String toString() {
		return "#" + posicao + "  Nivel:" + nivel + "  UserName:" + userName + "  Pontuacao:" + pontuacao;
	}
	
	/**
	 * Efectua a comparacao entre dois PlayersScores e verifica o que possui a pontuacao mais alta
	 */
	@Override
	public int compareTo(PlayerScore playerscore) {
//		if (this.getUserName().compareTo(playerscore.getUserName())<0){
//			return -1;
//		}else{
//			return 1;
//		}
		return this.getPontuacao() - playerscore.getPontuacao();
	}

}
