package pt.iul.ista.poo.utils;

import java.awt.event.KeyEvent;

/**
 * @author POO2016
 * 
 *         Cardinal directions
 *
 */

public enum Direction {
	LEFT(new Vector2D(-1, 0)), UP(new Vector2D(0, -1)), RIGHT(new Vector2D(1, 0)), DOWN(new Vector2D(0, 1));

	private Vector2D vector;

	/**
	 * Cria uma direc�o dado um vector
	 * @param vector
	 */
	Direction(Vector2D vector) {
		this.vector = vector;
	}

	/**
	 * Devolve uma direccao em forma de vector
	 * @return vector
	 */
	public Vector2D asVector() { //converte uma direccao num vector
		return vector;
	}

	/**
	 * 
	 * @param keyCode
	 * @return Direction
	 * Devolve uma direccao para uma determinada tecla pressionada
	 */
	public static Direction directionFor(int keyCode) {
		switch (keyCode) {
		case KeyEvent.VK_DOWN:
			return DOWN;
		case KeyEvent.VK_UP:
			return UP;
		case KeyEvent.VK_LEFT:
			return LEFT;
		case KeyEvent.VK_RIGHT:
			return RIGHT;
		}
		throw new IllegalArgumentException();
	}

	/**
	 * Ve se a tecla pressionada tem alguma direccao associada
	 * @param lastKeyPressed
	 * @return boolean
	 */
	public static boolean isDirection(int lastKeyPressed) {
		return lastKeyPressed >= KeyEvent.VK_LEFT && lastKeyPressed <= KeyEvent.VK_DOWN;
	}

	public Direction inverse() {
		switch (this) {
		case UP:
			return DOWN;
		case DOWN:
			return UP;
		case RIGHT:
			return LEFT;
		case LEFT:
			return RIGHT;
		}
		return null;
	}
}
