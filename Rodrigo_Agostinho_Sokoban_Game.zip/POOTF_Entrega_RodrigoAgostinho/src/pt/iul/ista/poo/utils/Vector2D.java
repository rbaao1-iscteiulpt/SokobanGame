package pt.iul.ista.poo.utils;

/**
 * @author Rodrigo
 *
 */
public class Vector2D {
	
	private int x;
	private int y;
	
	/**
	 * Cria um vector dada uma coordenada x e uma coordenada y
	 * @param x horizontal coordinate
	 * @param y vertical coordinate
	 */
	public Vector2D(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * @return horizontal coordinate
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * @return vertical coordinate
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * Efectua a soma entre as coordenadas de dois vectores
	 * @param vector
	 * @return Vector
	 */
	public Vector2D plus(Vector2D vector) {
		return new Vector2D(getX() + vector.getX(), getY() + vector.getY());
	}

	/**
	 * Efectua a subtraccao entre as coordenadas de dois vectores
	 * @param vector
	 * @return Vector
	 */
	public Vector2D minus(Vector2D vector) {
		return new Vector2D(getX() - vector.getX(), getY() - vector.getY());
	}

	@Override
	public String toString() {
		return "<" + x + ", " + y + ">";
	}

}
