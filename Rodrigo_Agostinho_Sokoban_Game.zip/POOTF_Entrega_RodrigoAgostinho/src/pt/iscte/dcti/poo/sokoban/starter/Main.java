package pt.iscte.dcti.poo.sokoban.starter;

import javax.swing.JOptionPane;

import MotorDeJogo.SokobanGame;
import User.User;
import pt.iul.ista.poo.gui.ImageMatrixGUI;

public class Main {
	
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Bem-Vindo ao SokobanGame\nObjectivo: Mover as caixas para os alvos assinalados antes de esgotar a energia disponivel...\nInstrucoes:\n - Mover para baixo\n - Mover para cima\n - Mover para a direira\n - Mover para a esquerda\n - Mover aleatoriamente\n");
		String userName = JOptionPane.showInputDialog("Insira username");
		User user = new User(userName);
		SokobanGame s = new SokobanGame(user);
		ImageMatrixGUI.getInstance().addObserver(s);
		ImageMatrixGUI.getInstance().go();
	}

}

