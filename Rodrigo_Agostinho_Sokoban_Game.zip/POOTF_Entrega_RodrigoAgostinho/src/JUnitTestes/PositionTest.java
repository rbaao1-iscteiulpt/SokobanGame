package JUnitTestes;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import pt.iul.ista.poo.utils.Position;
import pt.iul.ista.poo.utils.Vector2D;

/**
 * 
 * @author Rodrigo
 *
 */

public class PositionTest {

	private Position position;

	@Before
	public void setUp() throws Exception {
		position = new Position(1, 2);
	}
	
	@Test
	public void testConstructor() {
		assertEquals(1, position.getX());
		assertEquals(2, position.getY());
	}

	@Test
	public void testPlus() {
		assertEquals(new Position(1, 1), position.plus(new Vector2D(0, -1)));
		assertEquals(new Position(0, 0), position.plus(new Vector2D(-1, -2)));
	}

	@Test
	public void testGetX() {
		assertEquals(1, position.getX());
	}

	@Test
	public void testGetY() {
		assertEquals(2, position.getY());
	}
	

}
