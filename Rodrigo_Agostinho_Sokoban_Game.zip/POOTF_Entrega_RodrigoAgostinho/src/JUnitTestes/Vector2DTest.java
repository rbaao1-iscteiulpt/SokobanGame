package JUnitTestes;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import pt.iul.ista.poo.utils.Vector2D;

/**
 * 
 * @author Rodrigo
 *
 */

public class Vector2DTest {

	private Vector2D vector;
	
	@Before
	public void setUp() throws Exception {
		vector = new Vector2D(1, 1);
	}	
	
	@Test
	public void testConstructor() {
		assertEquals(1, vector.getX());
		assertEquals(1, vector.getY());
	}

	@Test
	public void testPlus() {		
		assertEquals(new Vector2D(5, 4).getX(), vector.plus(new Vector2D(4, 3)).getX());
		assertEquals(new Vector2D(5, 4).getY(), vector.plus(new Vector2D(4, 3)).getY());
		assertEquals(new Vector2D(0, 0).getX(), vector.plus(new Vector2D(-1, -1)).getX());
		assertEquals(new Vector2D(0, 0).getY(), vector.plus(new Vector2D(-1, -1)).getY());
	}

	@Test
	public void testMinus() {		
		assertEquals(new Vector2D(-1, 1).getX(), vector.minus(new Vector2D(2,0)).getX());
		assertEquals(new Vector2D(-1, 1).getY(), vector.minus(new Vector2D(2,0)).getY());
		assertEquals(new Vector2D(2, 2).getX(), vector.minus(new Vector2D(-1, -1)).getX());
		assertEquals(new Vector2D(2, 2).getY(), vector.minus(new Vector2D(-1, -1)).getY());
	}

	@Test
	public void testGetX() {
		assertEquals(1, vector.getX());
	}

	@Test
	public void testGetY() {
		assertEquals(1, vector.getY());
	}
	
}
