package JUnitTestes;

import static org.junit.Assert.*;

import org.junit.Test;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Vector2D;

/**
 * 
 * @author Rodrigo
 *
 */

public class DirectionTest {

	@Test
	public void testAsVector() {
		assertEquals(Direction.UP.asVector().getX(), new Vector2D(0, -1).getX());
		assertEquals(Direction.UP.asVector().getY(), new Vector2D(0, -1).getY());
		assertEquals(Direction.DOWN.asVector().getX(), new Vector2D(0, 1).getX());
		assertEquals(Direction.DOWN.asVector().getY(), new Vector2D(0, 1).getY());
		assertEquals(Direction.LEFT.asVector().getX(), new Vector2D(-1, 0).getX());
		assertEquals(Direction.LEFT.asVector().getY(), new Vector2D(-1, 0).getY());
		assertEquals(Direction.RIGHT.asVector().getX(), new Vector2D(1, 0).getX());
		assertEquals(Direction.RIGHT.asVector().getY(), new Vector2D(1, 0).getY());
	}

}


